/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package mx.itson.palindromo.business;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author geniuslab
 */
public class PalindromoTest {
    
    public PalindromoTest() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }

    /**
     * Test of esPalindromo method, of class Palindromo.
     */
    @Test
    public void testEsPalindromo() {
        System.out.println("esPalindromo");
        String phrase = "";
        boolean expResult = false;
        boolean result = Palindromo.esPalindromo(phrase);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of deshacer method, of class Palindromo.
     */
    @Test
    public void testDeshacer() {
        System.out.println("deshacer");
        String palindromoBueno = "";
        Palindromo instance = new Palindromo();
        String expResult = "";
        String result = instance.deshacer(palindromoBueno);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of sumar method, of class Palindromo.
     */
    @Test
    public void testSumar() {
        System.out.println("sumar");
        int a = 5;
        int b = 60;
        Palindromo instance = new Palindromo();
        //Expexted result
        int expResult = 65;
        //Resultado real/obtenido
        int result = instance.sumar(a, b);
        assertEquals(expResult, result);
        // ToDo review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }
    
}
